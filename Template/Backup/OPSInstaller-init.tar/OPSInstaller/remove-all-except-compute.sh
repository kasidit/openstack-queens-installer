#!/bin/bash
#
cd $HOME/OPSInstaller/
pwd
rm -rf ./controller
rm -rf ./network
#rm -rf ./compute
rm -rf ./compute1
rm -rf ./installer
rm -rf ./remove-all-*
