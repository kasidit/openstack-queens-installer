sed -i "s/localrepo/vasabi-1234local_repo4321-ibasav/g" local-sources.list
sed -i "s/localsecurityrepo/vasabi-1234local_security_repo4321-ibasav/g" local-sources.list

