# Openstack icehouse installation script on ubuntu 14.04 
# by kasidit chanchio
# vasabilab, dept of computer science, 
# Thammasat University, Thailand
#
# Copyright 2014  Kasidit Chanchio
#
# run with sudo or as root.
#
#!/bin/bash -x
#
echo service apache2 restart
service apache2 restart
